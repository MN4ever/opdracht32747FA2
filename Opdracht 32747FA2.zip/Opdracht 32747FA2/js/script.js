function updateTextInput(val) {
  document.getElementById('textInput').value=val; 
}